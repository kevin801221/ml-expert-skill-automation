"""Generic tabular binary-classification pipeline for AUC competitions.

Contract (the LLM agent stays thin; this script carries the recipe):
- Always leaves a valid predictions.csv on disk, even on crash (constant fallback).
- Stages: fallback -> quick LGBM (single split) -> 5-fold LGBM CV -> XGB rank-average blend.
- Each stage atomically overwrites the output file and prints a STATUS line for the agent to poll.
- No imputers/scalers fitted outside folds: NaNs are left to native GBDT handling (zero leak surface).
- Time-budget aware: skips remaining folds/stages when the budget would be exceeded.

Usage: python run_pipeline.py [--budget SECONDS] [--out predictions.csv] [--data-dir DIR] [--selftest]
"""
import argparse
import os
import sys
import time
import traceback

import numpy as np
import pandas as pd

T0 = time.monotonic()
SEED = 42


def log(msg):
    print(msg, flush=True)


def remaining(budget):
    return budget - (time.monotonic() - T0)


def find_data(data_dir):
    for d in [data_dir, '.', 'data']:
        if d and os.path.exists(os.path.join(d, 'train.csv')):
            return tuple(os.path.join(d, f) for f in ('train.csv', 'test.csv', 'sample_submission.csv'))
    raise FileNotFoundError('train.csv not found (looked in --data-dir, ., ./data)')


def write_predictions(sample, id_col, target_col, test_ids, preds, out):
    preds = np.clip(np.asarray(preds, dtype=float), 0.0, 1.0)
    sub = sample[[id_col]].copy()
    if test_ids is not None:
        m = pd.Series(preds, index=test_ids)
        sub[target_col] = sub[id_col].map(m).fillna(float(preds.mean()))
    else:
        sub[target_col] = preds[: len(sub)]
    tmp = out + '.tmp'
    sub.to_csv(tmp, index=False)
    os.replace(tmp, out)


def pick_backend():
    for name, mod in (('lgb', 'lightgbm'), ('xgb', 'xgboost'), ('sk', 'sklearn')):
        try:
            __import__(mod)
            return name
        except ImportError:
            continue
    raise ImportError('no GBDT backend available')


def prepare(train, test, id_col, target_col, backend):
    feats = [c for c in test.columns if c != id_col and c in train.columns and c != target_col]
    X, Xt = train[feats].copy(), test[feats].copy()
    for c in feats:
        if not pd.api.types.is_numeric_dtype(X[c]):  # object / str / datetime -> categorical
            if X[c].nunique() > 1000:  # ponytail: high-cardinality -> frequency encode, target encoding if it ever matters
                freq = X[c].value_counts(normalize=True)
                X[c] = X[c].map(freq).astype(float)
                Xt[c] = Xt[c].map(freq).astype(float)
            else:
                cats = pd.Categorical(pd.concat([X[c].astype(str), Xt[c].astype(str)])).categories
                X[c] = pd.Categorical(X[c].astype(str), categories=cats)
                Xt[c] = pd.Categorical(Xt[c].astype(str), categories=cats)
    const = [c for c in feats if X[c].nunique(dropna=False) <= 1]
    X, Xt = X.drop(columns=const), Xt.drop(columns=const)
    if backend == 'sk':  # HistGB: category dtype -> codes (version-safe)
        for c in X.columns:
            if str(X[c].dtype) == 'category':
                X[c], Xt[c] = X[c].cat.codes, Xt[c].cat.codes
    return X, Xt


def fit_predict(backend, Xtr, ytr, Xva, yva, Xte):
    if backend == 'lgb':
        from lightgbm import LGBMClassifier, early_stopping
        m = LGBMClassifier(n_estimators=3000, learning_rate=0.05, num_leaves=63,
                           subsample=0.8, subsample_freq=1, colsample_bytree=0.8,
                           random_state=SEED, n_jobs=-1, verbosity=-1)
        m.fit(Xtr, ytr, eval_set=[(Xva, yva)], eval_metric='auc',
              callbacks=[early_stopping(100, verbose=False)])
    elif backend == 'xgb':
        from xgboost import XGBClassifier
        m = XGBClassifier(n_estimators=3000, learning_rate=0.05, max_depth=6,
                          subsample=0.8, colsample_bytree=0.8, tree_method='hist',
                          enable_categorical=True, eval_metric='auc',
                          early_stopping_rounds=100, random_state=SEED, n_jobs=-1, verbosity=0)
        m.fit(Xtr, ytr, eval_set=[(Xva, yva)], verbose=False)
    else:
        from sklearn.ensemble import HistGradientBoostingClassifier
        m = HistGradientBoostingClassifier(max_iter=500, learning_rate=0.05,
                                           early_stopping=True, random_state=SEED)
        m.fit(Xtr, ytr)
    return m.predict_proba(Xva)[:, 1], m.predict_proba(Xte)[:, 1]


def run_cv(backend, X, y, Xt, budget, n_folds=5):
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import KFold, StratifiedKFold
    if pd.Series(y).value_counts().min() >= n_folds:
        splits = StratifiedKFold(n_folds, shuffle=True, random_state=SEED).split(X, y)
    else:
        splits = KFold(n_folds, shuffle=True, random_state=SEED).split(X)
    oof = np.full(len(y), np.nan)
    test_preds, fold_time = [], None
    for i, (tr, va) in enumerate(splits):
        if fold_time is not None and remaining(budget) < fold_time * 1.3 + 30:
            log(f'STATUS CV_TRUNCATED backend={backend} folds_done={i}')
            break
        t = time.monotonic()
        vp, tp = fit_predict(backend, X.iloc[tr], y[tr], X.iloc[va], y[va], Xt)
        fold_time = time.monotonic() - t
        oof[va] = vp
        test_preds.append(tp)
        log(f'fold {i + 1}/{n_folds} backend={backend} auc={roc_auc_score(y[va], vp):.5f} time={fold_time:.0f}s')
    done = ~np.isnan(oof)
    auc = roc_auc_score(y[done], oof[done]) if done.any() else float('nan')
    return oof, np.mean(test_preds, axis=0), auc, bool(done.all())


def rank_avg(a, b):
    ra = pd.Series(a).rank(pct=True).values
    rb = pd.Series(b).rank(pct=True).values
    return (ra + rb) / 2.0


def main(budget, out, data_dir):
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import train_test_split

    train_p, test_p, sub_p = find_data(data_dir)
    sample = pd.read_csv(sub_p)
    id_col, target_col = sample.columns[0], sample.columns[1]
    train, test = pd.read_csv(train_p), pd.read_csv(test_p)
    test_ids = test[id_col] if id_col in test.columns else None
    log(f'data train={train.shape} test={test.shape} id={id_col} target={target_col}')

    # Stage 0: constant fallback so a valid file exists from second one.
    base = float(train[target_col].mean()) if target_col in train.columns else 0.5
    write_predictions(sample, id_col, target_col, test_ids, np.full(len(sample), base), out)
    log('STATUS FALLBACK_READY')

    y = train[target_col].values
    if len(np.unique(y[~pd.isna(y)])) < 2:
        log('STATUS DONE stage=fallback reason=single_class_target')
        return
    backend = pick_backend()
    X, Xt = prepare(train, test, id_col, target_col, backend)
    log(f'backend={backend} features={X.shape[1]}')

    # Stage 1: quick single-split model.
    itr, iva = train_test_split(np.arange(len(y)), test_size=0.2, random_state=SEED, stratify=y)
    vp, tp = fit_predict(backend, X.iloc[itr], y[itr], X.iloc[iva], y[iva], Xt)
    quick_auc = roc_auc_score(y[iva], vp)
    write_predictions(sample, id_col, target_col, test_ids, tp, out)
    log(f'STATUS QUICK_DONE val_auc={quick_auc:.5f}')

    # Stage 2: 5-fold CV with the primary backend.
    quick_time = time.monotonic() - T0
    if remaining(budget) < quick_time * 5:
        log(f'STATUS DONE stage=quick val_auc={quick_auc:.5f} reason=budget')
        return
    t_cv = time.monotonic()
    oof1, test1, auc1, full1 = run_cv(backend, X, y, Xt, budget)
    cv_time = time.monotonic() - t_cv
    best_auc, best_test, best_stage = auc1, test1, f'cv_{backend}'
    write_predictions(sample, id_col, target_col, test_ids, best_test, out)
    log(f'STATUS CV_DONE oof_auc={auc1:.5f} complete={full1}')

    # Stage 3: second backend + rank-average blend, only with full OOF and enough budget.
    second = 'xgb' if backend == 'lgb' else None
    if second and full1 and remaining(budget) > cv_time * 1.2 + 60:
        try:
            __import__('xgboost')
            oof2, test2, auc2, full2 = run_cv(second, X, y, Xt, budget)
            if full2:
                blend_auc = roc_auc_score(y, rank_avg(oof1, oof2))
                log(f'blend candidates: {best_stage}={auc1:.5f} cv_xgb={auc2:.5f} blend={blend_auc:.5f}')
                for auc_c, test_c, stage_c in ((auc2, test2, 'cv_xgb'),
                                               (blend_auc, rank_avg(test1, test2), 'blend')):
                    if auc_c > best_auc:
                        best_auc, best_test, best_stage = auc_c, test_c, stage_c
                write_predictions(sample, id_col, target_col, test_ids, best_test, out)
                log(f'STATUS BLEND_DONE stage={best_stage} oof_auc={best_auc:.5f}')
        except ImportError:
            pass

    log(f'STATUS DONE stage={best_stage} oof_auc={best_auc:.5f} elapsed={time.monotonic() - T0:.0f}s')


def selftest():
    import tempfile
    from sklearn.datasets import make_classification
    d = tempfile.mkdtemp()
    rng = np.random.RandomState(0)
    Xa, ya = make_classification(3000, 20, n_informative=8, random_state=0)
    df = pd.DataFrame(Xa, columns=[f'col_{i}' for i in range(20)])
    df['cat_a'] = rng.choice(list('abcd'), len(df))
    df.loc[rng.rand(len(df)) < 0.1, 'col_3'] = np.nan  # NaN path
    tr, te = df.iloc[:2000].copy(), df.iloc[2000:].copy()
    tr['target'] = ya[:2000]
    tr.insert(0, 'id', range(2000))
    te.insert(0, 'id', range(2000, 3000))
    tr.to_csv(os.path.join(d, 'train.csv'), index=False)
    te.to_csv(os.path.join(d, 'test.csv'), index=False)
    pd.DataFrame({'id': te['id'], 'target': 0.5}).to_csv(os.path.join(d, 'sample_submission.csv'), index=False)
    os.chdir(d)  # match real usage: run next to the data so the crash handler resolves paths
    main(budget=300, out='predictions.csv', data_dir=d)
    sub = pd.read_csv('predictions.csv')
    assert list(sub.columns) == ['id', 'target'] and len(sub) == 1000
    assert sub['target'].between(0, 1).all() and sub['target'].nunique() > 1
    from sklearn.metrics import roc_auc_score
    holdout_auc = roc_auc_score(ya[2000:], sub['target'])
    assert holdout_auc > 0.7, f'holdout auc too low: {holdout_auc}'
    log(f'SELFTEST OK holdout_auc={holdout_auc:.5f}')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--budget', type=float, default=2100.0, help='wall-clock seconds this script may use')
    p.add_argument('--out', default='predictions.csv')
    p.add_argument('--data-dir', default=None)
    p.add_argument('--selftest', action='store_true')
    a = p.parse_args()
    try:
        if a.selftest:
            selftest()
        else:
            main(a.budget, a.out, a.data_dir)
    except Exception:
        traceback.print_exc()
        # Crash fallback: never leave the agent without a submittable file.
        try:
            if not os.path.exists(a.out):
                _, _, sub_p = find_data(a.data_dir)
                s = pd.read_csv(sub_p)
                s[s.columns[1]] = 0.5
                s.to_csv(a.out, index=False)
            log('STATUS DONE stage=crash_fallback')
        except Exception:
            traceback.print_exc()
            log('STATUS FATAL no_submission_possible')
        sys.exit(0)
